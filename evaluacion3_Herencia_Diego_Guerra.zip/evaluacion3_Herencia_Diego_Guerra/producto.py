class Producto:
    def __init__(self,idProducto,nombre,stock,proveedor):
        self.idProducto = idProducto
        self.nombre = nombre 
        self.stock = stock
        self.proveedor = proveedor

    def mostrarProducto(self):
        return "IDProducto: " + str(self.idProducto)+"\n"+\
               "Nombre producto: " + self.nombre+"\n"+\
               "Stock producto: " + str(self.stock) + "\n"


    
