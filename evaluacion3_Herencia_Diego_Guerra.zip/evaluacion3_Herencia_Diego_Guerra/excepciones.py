
def opcionIncorrecta():
    try:
        opcion = int(input("Ingrese una opcion: "))
        return opcion
    except:
        print("La opcion ingresada no es correcta")


def idIncorrecto():
    try:
        dato = int(input("Ingrese el id: "))
        return dato
    except:
        print("El dato ingresado no es correcto")


def stockIncorrecto():
    try:
        dato = int(input("Ingrese el stock: "))
        return dato
    except:
        print("El dato ingresado no es correcto")


def idPrecioIncorrecto():
    try:
        dato = int(input("Ingrese el id del Precio: "))
        return dato
    except:
        print("El dato ingresado no es correcto")

def preciolistaIncorrecto():
    try:
        dato = int(input("Ingrese el precio de lista: "))
        return dato
    except:
        print("El dato ingresado no es correcto")


def precioventaIncorrecto():
    try:
        dato = int(input("Ingrese el precio de venta: "))
        return dato
    except:
        print("El dato ingresado no es correcto") 


def eliminarIncorrecto(opcion,lista):
    try:
        lista.pop(opcion - 1)
        return lista
    except:
        print("El numero escogido es incorrecto")
        return False


def actualizarPrecio(lista,opcion):
    try:
        lista[opcion - 1].precioLista = int(input("Indique el nuevo precio de lista: "))
        lista[opcion - 1].precioVenta = int(input("Indique el nuevo precio de venta: "))
        return lista
    except:
        print("El valor ingresado es incorrecto")
        return False

def actualizarStock(lista,opcion):
    try:
        lista[opcion - 1].stock = int(input("Indique la nueva cantidad de stock: "))
        return lista
    except:
        print("El valor ingresado es incorrecto")
        return False                                



                
