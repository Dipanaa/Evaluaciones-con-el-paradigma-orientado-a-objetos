
from excepciones import opcionIncorrecta
from precio import Precio
from proveedor import Proveedor
#Autor: Diego Guerra
#Evaluacion 3 Programacion orientada a objetos
#Nota: Para este caso el stock bajo se traduce en un valor menor a 200 unidades


def menu():
    print("\n")
    print("--------------Escoga una opcion-----------------")
    return"1. Agregar un producto, con su precio y proveedor\n" + \
           "2. Eliminar un producto\n" + \
           "3. Actualizar precios de un producto (lista y venta)\n" + \
           "4. Actualizar stock\n" + \
           "5. Mostrar productos con bajo stock\n" + \
           "6. Valorizar stock\n" + \
           "7. Salir \n"



lista_ini = []

a2 = Proveedor("Coca cola company","Liquidos")
a = Precio(1,"Fanta",300,a2,1,500,700)
lista_ini.append(a)

b2 = Proveedor("Quilque S.A","Lacteos")
b = Precio(2,"Queso Ranco Quilque",150,b2,2,800,1400)
lista_ini.append(b)

c2 = Proveedor("Nabisco","Galletas")
c = Precio(3,"Galletas Oreo Black",600,c2,3,600,650)
lista_ini.append(c)

d2 = Proveedor("Coca cola Company","Liquidos")
d = Precio(4,"Coca cola zero",450,d2,4,600,650)
lista_ini.append(d)

e2 = Proveedor("Colun","Liquidos")
e = Precio(5,"Leche chocolate",120,e2,5,400,600)
lista_ini.append(e)


i = True
while(i):
    print(menu())
    opcion = opcionIncorrecta()
    if(opcion == 1):
        q = e.agregarProductoProveedor()
        if (q == False):
            print("El producto no fue agregado debido a error en los datos ingresados")
        else:
            lista_ini.append(q)
            print("------------PRODUCTO AGREGADO------------")
    if(opcion == 2):
        lista_p = []
        lista_p = e.eliminarProducto(lista_ini)
        if (lista_p != False):
            lista_ini = lista_p
            print("------------PRODUCTO ELIMINADO------------")
        else:
            print("El producto no fue eliminado debido a error en la opcion ingresada")   
        
    if(opcion == 3):
        lista_p = []
        lista_p = e.actualizarPreciop(lista_ini)
        if (lista_p != False):
            lista_ini = lista_p
            print("------------PRODUCTO ACTUALIZADO------------")
        else:
            print("El producto no fue actualizado debido a error en la opcion ingresada")   
        
    if(opcion == 4):
        lista_p = []
        lista_p = e.actualizarStock(lista_ini)
        if (lista_p != False):
            lista_ini = lista_p
            print("------------STOCK ACTUALIZADO------------")
        else:
            print("El stock no fue actualizado debido a error en la opcion ingresada")
    if(opcion == 5):
        e.mostrarStockBajo(lista_ini)
    if(opcion == 6):
        e.valorizarStock(lista_ini)
    if(opcion == 7):
        i = False



        

    
    











