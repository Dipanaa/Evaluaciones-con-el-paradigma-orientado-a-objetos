
from excepciones import opcionIncorrecta,idIncorrecto,stockIncorrecto,idPrecioIncorrecto,preciolistaIncorrecto,precioventaIncorrecto,eliminarIncorrecto,actualizarPrecio,actualizarStock
from producto import Producto
from proveedor import Proveedor

class Precio(Producto):
    def __init__(self, idProducto, nombre, stock, proveedor,idPrecio,precioLista,precioVenta):
        Producto.__init__(self,idProducto, nombre, stock, proveedor)
        self.idPrecio = idPrecio
        self.precioLista = precioLista
        self.precioVenta = precioVenta

    def mostrarPCompleto(self,lista,num):
        return lista[num].mostrarProducto() + \
               lista[num].proveedor.mostrarProveedor() + \
               "IDPrecio: " + str(lista[num].idPrecio) + "\n" +\
               "Precio lista: " + str(lista[num].precioLista) + "\n" +\
               "Precio venta: " + str(lista[num].precioVenta) + "\n"

    def escogerEleccion(self,lista):
        for a in range(0,len(lista)):
            print("#" + str(a+1))
            print(self.mostrarPCompleto(lista,a))
        opcion = int(input("Ingrese una eleccion: "))
        return opcion              

    def agregarProductoProveedor(self):
        idProducto = idIncorrecto()
        if(idProducto == None):
            return False
        nombre = input("Ingrese nombre del producto: ")
        stock = stockIncorrecto()
        if(stock== None):
            return False
        idPrecio = idPrecioIncorrecto()
        if(idPrecio== None):
            return False
        precioLista = preciolistaIncorrecto()
        if(precioLista== None):
            return False
        precioVenta = precioventaIncorrecto()
        if(precioVenta== None):
            return False
        nombreProveedor = input("Ingrese nombre del proveedor: ")
        categoria = input("Ingrese categoria del proveedor: ")
        dependencia = Proveedor(nombreProveedor,categoria)
        q = Precio(idProducto,nombre,stock,dependencia,idPrecio,precioLista,precioVenta)
        return q

    def eliminarProducto(self,lista):
        print("Escoga un producto que desea eliminar \n")
        opcion = self.escogerEleccion(lista)
        lista = eliminarIncorrecto(opcion,lista)
        return lista

    def actualizarPreciop(self,lista):
        print("Escoga un producto que desea actualizar precios")
        opcion = self.escogerEleccion(lista)
        lista = actualizarPrecio(lista,opcion)
        return lista

    def actualizarStock(self,lista):
        print("Escoga un producto que desea modificar el stock: ")
        opcion = self.escogerEleccion(lista)
        lista = actualizarStock(lista,opcion)
        return lista

    def mostrarStockBajo(self,lista):
        print("STOCK BAJO\n")
        for a in range(0,len(lista)):
            if (lista[a].stock < 200):
                print(self.mostrarPCompleto(lista,a))

    def valorizarStock(self,lista):
        print("Escoga un producto que desea saber el valor de la cantidad en bodega: ")
        opcion = self.escogerEleccion(lista)
        valorBodega = lista[opcion - 1].stock * lista[opcion - 1].precioLista
        print("El valor es de","$" + str(valorBodega))




        





