class Proveedor:
    def __init__(self,nombre,categoria):
        self.nombre = nombre
        self.categoria = categoria
        

    def mostrarProveedor(self):
        return "Nombre proveedor: " + self.nombre + "\n" +\
               "Categoria: " + self.categoria + "\n"

        