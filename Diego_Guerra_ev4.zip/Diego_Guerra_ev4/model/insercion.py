import mysql.connector
from mysql.connector import Error

class Model:
    def __init__(self):
        self.conexion = None
        try:
            self.conexion = mysql.connector.connect(
                host='localhost',
                port=3306,
                user='root',
                password='',
                db='prueba_1'
            )
        except Error as ex:
            print("Error de conexion: ", ex)



    def mostrarDatos(self,dato):
        print("ID: ",dato[0],"|","numMat: ",dato[1],"|","Nombre: ",dato[2],"|","Apellido: ",dato[3],"|","Asignatura: ",dato[4],"|","Nota: ",dato[5],"|","numEva: ",dato[6],"|")

    def filtrarNombres(self,datos_curso):
        lista_aux = []
        Suplente = True
        dato_aux = datos_curso[0][2] + " " + datos_curso[0][3]
        lista_aux.append(dato_aux)
        lista_aux.append(datos_curso[0][1])
        for name in datos_curso:
            Suplente = True
            if dato_aux != name[2] + " " + name[3]:
                for encontrar in range(0, len(lista_aux)):
                    if name[2] + " " + name[3] == lista_aux[encontrar]:
                        Suplente = False
                if Suplente == True:
                    dato_aux = name[2] + " " + name[3]
                    lista_aux.append(dato_aux)
                    lista_aux.append(name[1])
        return lista_aux

    def mostrarNombres(self,lista_nombres):
        contador = 0
        for name in range(0, len(lista_nombres)):
            print("#",contador + 1,lista_nombres[name])
            print("-----------------")
            contador += 1

    def crearPersona(self,datos):
        if self.conexion.is_connected():
            try:
                cursor = self.conexion.cursor()
                query = "Insert into curso(id,numMat,apellidos,nombres,asignatura,nota,numEva) values({0},{1},'{2}','{3}','{4}',{5},{6})"
                cursor.execute(query.format(datos[0],datos[1],datos[2],datos[3],datos[4],datos[5],datos[6]))
                self.conexion.commit()
            except Error as exception:
                print("El error obtenido dice: ",exception)

    def modificarNota(self):
        if self.conexion.is_connected():
            try:
                cursor = self.conexion.cursor()
                cursor.execute("select * from curso")
                datos_curso = cursor.fetchall()
                contador = 0
                lista_aux = []
                lista_nombres = []
                lista_numMat = []

                lista_aux = self.filtrarNombres(datos_curso)

                while(contador<len(lista_aux)):
                    lista_nombres.append(lista_aux[contador])
                    lista_numMat.append(lista_aux[contador+1])
                    contador+=2
                contador = 0

                self.mostrarNombres(lista_nombres)
                opcion = int(input("Escoga uno de los alumnos: "))
                lista_nombres = []
                print("Seleccione una de sus notas")
                for nota in datos_curso:
                    if lista_numMat[opcion-1] == nota[1]:
                        lista_nombres.append(nota[0])
                        print("Nota #"+str(contador+1)+":",nota[5])
                        print("-----------------")
                        contador+=1

                opcion = int(input("Seleccione una nota a modificar: "))

                nueva_nota = float(input("Escriba la nueva nota: "))
                cursor.execute("update curso set nota = {0} where curso.id = {1}".format(nueva_nota,lista_nombres[opcion-1]))
                self.conexion.commit()
            except Error as exception:
                print("El error obtenido dice: ",exception)

    def calcularPromedio(self):
        opcion_e= int(input("Seleccione 1 para calcular el promedio por asignatura o 2 para calcular el promedio general: "))
        cursor = self.conexion.cursor()
        cursor.execute("select * from curso")
        datos_curso = cursor.fetchall()
        if opcion_e == 1:
            contador = 0
            lista_aux = []
            lista_nombres = []
            lista_numMat = []

            lista_aux = self.filtrarNombres(datos_curso)

            while (contador < len(lista_aux)):
                lista_nombres.append(lista_aux[contador])
                lista_numMat.append(lista_aux[contador + 1])
                contador += 2
            contador = 0

            self.mostrarNombres(lista_nombres)

            opcion = int(input("Escoga uno de los alumnos: "))
            guardar_numMat = lista_numMat[opcion-1]
            lista_aux = []
            bandera = True
            for ramo in datos_curso:
                if guardar_numMat == ramo[1]:
                    bandera = True
                    for a in range(0,len(lista_aux)):
                        if ramo[4] == lista_aux[a]:
                            bandera = False
                    if bandera == True:
                        lista_aux.append(ramo[4])

            for a in range(0,len(lista_aux)):
                print("#",contador+1,lista_aux[a])
                print("-----------------")
                contador+=1

            opcion = int(input("Seleccione uno de los ramos: "))

            promedio = 0
            almacenar = 0
            for a in datos_curso:
                if guardar_numMat == a[1]:
                    if lista_aux[opcion-1] == a[4]:
                        promedio = promedio + a[5]
                        almacenar = almacenar + 1

            print("El promedio de la asignatura escogida es ",promedio/almacenar,"\n")


        if opcion_e == 2:
            contador = 0
            lista_aux = []
            lista_nombres = []
            lista_numMat = []

            lista_aux = self.filtrarNombres(datos_curso)

            while (contador < len(lista_aux)):
                lista_nombres.append(lista_aux[contador])
                lista_numMat.append(lista_aux[contador + 1])
                contador += 2
            contador = 0

            self.mostrarNombres(lista_nombres)

            opcion = int(input("Escoga uno de los alumnos: "))
            guardar_numMat = lista_numMat[opcion - 1]
            promedio = 0
            almacenar = 0
            for a in datos_curso:
                if guardar_numMat == a[1]:
                    promedio = promedio + a[5]
                    almacenar = almacenar + 1

            print("El promedio general es ",promedio/almacenar, "\n")




















