def Menu():
    print("Escoga una de las siguientes opciones \n"\
          "1.Agregar un estudiante \n"\
          "2.Modificar una nota obtenida \n"\
          "3.Calcular promedio por asignatura o general\n"\
          "4.Salir\n ")

def ingresarDatos():
    id = int(input("Ingrese la id: "))
    numMat = int(input("Ingrese el numMat: "))
    apellidos = input("Ingrese el apellido: ")
    nombres = input("Ingrese el nombre: ")
    asignatura = input("Ingrese la asignatura: ")
    nota = float(input("Ingrese la nota: "))
    numEva = int(input("Ingrese el numero de evaluacion: "))
    alumno = (id,numMat,apellidos,nombres,asignatura,nota,numEva)
    return alumno




