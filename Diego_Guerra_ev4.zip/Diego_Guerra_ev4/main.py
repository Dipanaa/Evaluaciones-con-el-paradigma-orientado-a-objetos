from model.insercion import Model
import view.functions

#Autor: Diego Guerra
#Asignatura: Programacion Orientada a Objetos N2-P1-C2
#*Observacion: Cada dato ingresado debe estar bien tipeado para evitar errores de informacion incluyendo mayusculas,minusculas y numeros.



a = True
b = Model()
c = ""
while(a == True):
    view.functions.Menu()
    seleccion = int(input("Eleccion: "))
    if seleccion == 1:
        c = view.functions.ingresarDatos()
        b.crearPersona(c)
        print("ALUMNO INGRESADO \n")
    if seleccion == 2:
        b.modificarNota()
        print("NOTA MODIFICADA \n")
    if seleccion == 3:
        b.calcularPromedio()
    if seleccion == 4:
        a = False
        b.conexion.close()

















